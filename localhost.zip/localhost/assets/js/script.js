// Цитаты дня
const quotes = [
    { text: "Человек создан для счастья, как птица для полета.", author: "Владимир Короленко" },
    { text: "Истина в вине, а здоровье в воде.", author: "Аристотель" },
    { text: "Быть или не быть — вот в чем вопрос.", author: "Уильям Шекспир" },
    { text: "Чем меньше женщину мы любим, тем легче нравимся мы ей.", author: "Александр Пушкин" },
    { text: "Все счастливые семьи похожи друг на друга, каждая несчастливая семья несчастлива по-своему.", author: "Лев Толстой" },
    { text: "Красота спасет мир.", author: "Фёдор Достоевский" },
    { text: "Любви все возрасты покорны.", author: "Александр Пушкин" },
    { text: "Мы в ответе за тех, кого приручили.", author: "Антуан де Сент-Экзюпери" },
    { text: "Ученье — свет, а неученье — тьма.", author: "Александр Суворов" },
    { text: "В человеке должно быть все прекрасно: и лицо, и одежда, и душа, и мысли.", author: "Антон Чехов" },
    { text: "Служить бы рад, прислуживаться тошно.", author: "Александр Грибоедов" },
    { text: "И дольше века длится день.", author: "Чингиз Айтматов" },
    { text: "Надо любить жизнь больше, чем смысл жизни.", author: "Фёдор Достоевский" }
];

const quoteElement = document.getElementById('quote-text');
const quoteAuthorElement = document.getElementById('quote-author');
const newQuoteButton = document.getElementById('new-quote-btn');
const shareQuoteButton = document.getElementById('share-quote-btn');

let currentQuoteIndex = -1;

function getRandomQuote() {
    let newIndex;
    do {
        newIndex = Math.floor(Math.random() * quotes.length);
    } while (newIndex === currentQuoteIndex && quotes.length > 1);
    
    currentQuoteIndex = newIndex;
    return quotes[currentQuoteIndex];
}

function updateQuote() {
    const randomQuote = getRandomQuote();
    
    // Анимация исчезновения
    quoteElement.style.opacity = 0;
    quoteAuthorElement.style.opacity = 0;
    
    setTimeout(() => {
        quoteElement.textContent = `"${randomQuote.text}"`;
        quoteAuthorElement.textContent = `— ${randomQuote.author}`;
        
        // Анимация появления
        quoteElement.style.opacity = 1;
        quoteAuthorElement.style.opacity = 1;
    }, 300);
}

newQuoteButton.addEventListener('click', updateQuote);

shareQuoteButton.addEventListener('click', () => {
    const currentQuote = quotes[currentQuoteIndex];
    const textToShare = `${currentQuote.text} — ${currentQuote.author}`;
    
    if (navigator.share) {
        navigator.share({
            title: 'Цитата дня - Классика Литературы',
            text: textToShare,
            url: window.location.href
        })
        .catch(error => console.log('Ошибка при попытке поделиться:', error));
    } else {
        // Fallback для браузеров, которые не поддерживают Web Share API
        navigator.clipboard.writeText(textToShare)
            .then(() => {
                alert('Цитата скопирована в буфер обмена!');
            })
            .catch(err => {
                console.error('Ошибка при копировании: ', err);
            });
    }
});

// Параллакс эффект для баннера
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const banner = document.querySelector('.banner-background');
    if (banner) {
        banner.style.transform = `translateY(${scrolled * 0.5}px)`;
    }
});

// Инициализация загрузки изображений
function initImageUpload() {
    const uploadArea = document.getElementById('image-upload');
    const fileInput = document.getElementById('author-image');
    const preview = document.getElementById('upload-preview');
    const previewImage = document.getElementById('preview-image');
    
    if (!uploadArea || !fileInput) return;
    
    // Обработчик клика по области загрузки
    uploadArea.addEventListener('click', function() {
        fileInput.click();
    });
    
    // Обработчик изменения файла
    fileInput.addEventListener('change', function(e) {
        handleImageUpload(e.target.files[0]);
    });
    
    // Обработчики drag & drop
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });
    
    uploadArea.addEventListener('dragleave', function() {
        uploadArea.classList.remove('dragover');
    });
    
    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleImageUpload(files[0]);
        }
    });
    
    // Обработчик удаления изображения
    const removeBtn = document.getElementById('remove-image');
    if (removeBtn) {
        removeBtn.addEventListener('click', function() {
            preview.style.display = 'none';
            fileInput.value = '';
            uploadArea.style.display = 'block';
        });
    }
}

// Обработка загрузки изображения
function handleImageUpload(file) {
    if (!file || !file.type.startsWith('image/')) {
        showNotification('Пожалуйста, выберите файл изображения', 'error');
        return;
    }
    
    if (file.size > 5 * 1024 * 1024) { // 5MB limit
        showNotification('Размер файла не должен превышать 5MB', 'error');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const preview = document.getElementById('upload-preview');
        const previewImage = document.getElementById('preview-image');
        const uploadArea = document.getElementById('image-upload');
        
        previewImage.src = e.target.result;
        preview.style.display = 'block';
        uploadArea.style.display = 'none';
        
        showNotification('Изображение успешно загружено', 'success');
    };
    
    reader.readAsDataURL(file);
}

// Инициализация загрузки изображений
function initImageUpload() {
    const uploadArea = document.getElementById('image-upload');
    const fileInput = document.getElementById('author-image');
    const preview = document.getElementById('upload-preview');
    const previewImage = document.getElementById('preview-image');
    
    if (!uploadArea || !fileInput) return;
    
    // Обработчик клика по области загрузки
    uploadArea.addEventListener('click', function() {
        fileInput.click();
    });
    
    // Обработчик изменения файла
    fileInput.addEventListener('change', function(e) {
        handleImageUpload(e.target.files[0]);
    });
    
    // Обработчики drag & drop
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });
    
    uploadArea.addEventListener('dragleave', function() {
        uploadArea.classList.remove('dragover');
    });
    
    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleImageUpload(files[0]);
        }
    });
    
    // Обработчик удаления изображения
    const removeBtn = document.getElementById('remove-image');
    if (removeBtn) {
        removeBtn.addEventListener('click', function() {
            preview.style.display = 'none';
            fileInput.value = '';
            uploadArea.style.display = 'block';
        });
    }
}

// Обработка загрузки изображения
function handleImageUpload(file) {
    if (!file || !file.type.startsWith('image/')) {
        showNotification('Пожалуйста, выберите файл изображения', 'error');
        return;
    }
    
    if (file.size > 5 * 1024 * 1024) { // 5MB limit
        showNotification('Размер файла не должен превышать 5MB', 'error');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const preview = document.getElementById('upload-preview');
        const previewImage = document.getElementById('preview-image');
        const uploadArea = document.getElementById('image-upload');
        
        previewImage.src = e.target.result;
        preview.style.display = 'block';
        uploadArea.style.display = 'none';
        
        showNotification('Изображение успешно загружено', 'success');
    };
    
    reader.readAsDataURL(file);
}

// Функции для слайдера баннера
function initBannerSlider() {
    const slides = document.querySelectorAll('.slide');
    const indicators = document.querySelectorAll('.indicator');
    const prevBtn = document.querySelector('.slider-prev');
    const nextBtn = document.querySelector('.slider-next');
    const progressBar = document.querySelector('.progress-bar');
    
    let currentSlide = 0;
    let slideInterval;
    let progressInterval;
    const slideDuration = 6000; // 6 секунд на каждый слайд
    let progress = 0;
    
    // Инициализация слайдера
    function initSlider() {
        // Запуск автоматической смены слайдов
        startAutoSlide();
        
        // Обработчики для кнопок навигации
        if (prevBtn) {
            prevBtn.addEventListener('click', goToPrevSlide);
        }
        
        if (nextBtn) {
            nextBtn.addEventListener('click', goToNextSlide);
        }
        
        // Обработчики для индикаторов
        indicators.forEach((indicator, index) => {
            indicator.addEventListener('click', () => {
                goToSlide(index);
            });
        });
        
        // Пауза при наведении на слайдер
        const slider = document.querySelector('.banner-slider');
        if (slider) {
            slider.addEventListener('mouseenter', pauseSlider);
            slider.addEventListener('mouseleave', resumeSlider);
        }
        
        // Обработка касаний для мобильных устройств
        let touchStartX = 0;
        let touchEndX = 0;
        
        if (slider) {
            slider.addEventListener('touchstart', e => {
                touchStartX = e.changedTouches[0].screenX;
            });
            
            slider.addEventListener('touchend', e => {
                touchEndX = e.changedTouches[0].screenX;
                handleSwipe();
            });
        }
        
        function handleSwipe() {
            const swipeThreshold = 50;
            const diff = touchStartX - touchEndX;
            
            if (Math.abs(diff) > swipeThreshold) {
                if (diff > 0) {
                    goToNextSlide();
                } else {
                    goToPrevSlide();
                }
            }
        }
    }
    
    // Переход к определенному слайду
    function goToSlide(slideIndex) {
        // Сброс прогресс-бара
        resetProgressBar();
        
        // Скрытие текущего слайда
        slides[currentSlide].classList.remove('active');
        indicators[currentSlide].classList.remove('active');
        
        // Обновление текущего слайда
        currentSlide = slideIndex;
        
        // Показ нового слайда
        slides[currentSlide].classList.add('active');
        indicators[currentSlide].classList.add('active');
        
        // Перезапуск автоматической смены
        restartAutoSlide();
    }
    
    // Переход к следующему слайду
    function goToNextSlide() {
        const nextSlide = (currentSlide + 1) % slides.length;
        goToSlide(nextSlide);
    }
    
    // Переход к предыдущему слайду
    function goToPrevSlide() {
        const prevSlide = (currentSlide - 1 + slides.length) % slides.length;
        goToSlide(prevSlide);
    }
    
    // Запуск автоматической смены слайдов
    function startAutoSlide() {
        slideInterval = setInterval(goToNextSlide, slideDuration);
        startProgressBar();
    }
    
    // Перезапуск автоматической смены
    function restartAutoSlide() {
        clearInterval(slideInterval);
        clearInterval(progressInterval);
        startAutoSlide();
    }
    
    // Пауза слайдера
    function pauseSlider() {
        clearInterval(slideInterval);
        clearInterval(progressInterval);
    }
    
    // Возобновление слайдера
    function resumeSlider() {
        restartAutoSlide();
    }
    
    // Прогресс-бар для визуализации времени смены слайдов
    function startProgressBar() {
        progress = 0;
        progressBar.style.width = '0%';
        
        progressInterval = setInterval(() => {
            progress += 100 / (slideDuration / 100);
            progressBar.style.width = `${progress}%`;
            
            if (progress >= 100) {
                clearInterval(progressInterval);
            }
        }, 100);
    }
    
    // Сброс прогресс-бара
    function resetProgressBar() {
        progress = 0;
        progressBar.style.width = '0%';
        clearInterval(progressInterval);
    }
    
    // Инициализация слайдера при загрузке DOM
    if (slides.length > 0) {
        initSlider();
    }
    
    // Добавление клавиатурной навигации
    document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            goToPrevSlide();
        } else if (e.key === 'ArrowRight') {
            goToNextSlide();
        } else if (e.key === ' ') {
            // Пауза/возобновление при нажатии пробела
            if (slideInterval) {
                pauseSlider();
            } else {
                resumeSlider();
            }
        }
    });
    
    // Возврат публичных методов для возможного использования извне
    return {
        goToSlide,
        goToNextSlide,
        goToPrevSlide,
        pauseSlider,
        resumeSlider
    };
}

// Инициализация слайдера при загрузке DOM
document.addEventListener('DOMContentLoaded', function() {
    // Если мы на главной странице со слайдером
    if (document.querySelector('.banner-slider')) {
        window.bannerSlider = initBannerSlider();
    }
});
