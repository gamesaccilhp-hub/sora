<?php
// var_dump($_SESSION);

// выход из аккаунта
if(isset($_GET['q'])){
    if($_GET['q'] == 'exit'){
        session_unset();
        echo'<script>document.location.href="/"</script>';
    }
}

// определение пользователя
if(isset($_SESSION['UID'])){
    $session_uid = $_SESSION['UID'];
    $sql = "SELECT * FROM users WHERE id = '$session_uid'";
    $USER = $connect->query($sql)->fetch();

    // echo $USER['email'];
}

?>