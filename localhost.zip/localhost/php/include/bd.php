<?php
try{
    $connect = new PDO ("mysql:host=localhost;dbname=crud",'root','');
}catch(PDOException $error){
    echo $error;
}
?>