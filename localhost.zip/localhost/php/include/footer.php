<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-column">
                <div class="footer-logo">
                    <i class="fas fa-book-open"></i>
                    <span>LitWiki</span>
                </div>
                <p class="footer-description">Энциклопедия классической литературы для всех ценителей прекрасного. Мы стремимся сохранить и популяризировать мировое литературное наследие.</p>
                <div class="footer-social">
                    <a href="#" class="social-link"><i class="fab fa-vk"></i></a>
                    <a href="https://web.telegram.org/k/#-2115338148" class="social-link"><i class="fab fa-telegram"></i></a>
                </div>
            </div>
            <div class="footer-column">
                <h3 class="footer-title">Разделы</h3>
                <ul class="footer-links">
                    <li><a href="/tovary"><i class="fas fa-chevron-right"></i> Авторы</a></li>
                    <li><a href="/tovary"><i class="fas fa-chevron-right"></i> Произведения</a></li>
                    <li><a href="/age"><i class="fas fa-chevron-right"></i> Литературные эпохи</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3 class="footer-title">Сообщество</h3>
                <ul class="footer-links">
                    <li><a href="/add_tovar"><i class="fas fa-chevron-right"></i> Создать страницу</a></li>
                </ul>
            </div>
            <div class="footer-column">
                <h3 class="footer-title">Контакты</h3>
                <ul class="footer-links">
                    <li><a href="#"><i class="fas fa-chevron-right"></i> О нас</a></li>
                    <li><a href="#"><i class="fas fa-chevron-right"></i> Связаться с нами</a></li>
                    <li><a href="#"><i class="fas fa-chevron-right"></i> Политика конфиденциальности</a></li>
                    <li><a href="#"><i class="fas fa-chevron-right"></i> Политика обработки преоснальных данных</a></li>
                    <li><a href="#"><i class="fas fa-chevron-right"></i> Условия использования</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p class="copyright">&copy; 2025 Классика Литературы. Все права защищены.</p>
        </div>
    </div>
</footer>