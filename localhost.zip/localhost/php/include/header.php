<header id="header">
    <div class="container">
        <nav>
            <div class="logo">
                <i class="fas fa-book-open"></i>
                <span>LitWiki</span>
            </div>
            <ul class="nav-links">

                <li><a href="/" class="nav-link">Главная</a></li>
                <li><a href="/authors" class="nav-link">Авторы</a></li>

                <?php if(isset($_SESSION['UID'])): ?>
                    <!-- если пользователь авторизован -->
                    <li><a href="/profile" class="nav-link">Профиль</a></li>
                <?php else: ?>
                    
                    <!-- если пользователь не авторизован -->
                    <li><a href="/signup" class="btn btn-outline" style="padding: 8px 20px;">Регистрация</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>