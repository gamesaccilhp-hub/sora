<?php
// создание массива со всеми товарами
$sql = "SELECT * FROM authors";
$authors = $connect -> query($sql);
?>


<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Каталог авторов - Классика Литературы</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;0,700;1,400&family=Playfair+Display:wght@400;500;700;800&display=swap" rel="stylesheet">
    <style>
        /* Дополнительные стили для страницы каталога */
        .catalog-header {
            text-align: center;
            padding: 100px 0 60px;
            background: linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
            color: var(--light);
            margin-bottom: 50px;
        }
        
        .catalog-title {
            font-size: 3rem;
            margin-bottom: 20px;
            color: var(--light);
        }
        
        .catalog-subtitle {
            font-size: 1.3rem;
            max-width: 600px;
            margin: 0 auto;
            opacity: 0.9;
        }
        
        .catalog-filters {
            max-width: 1200px;
            margin: 0 auto 40px;
            padding: 0 20px;
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
            justify-content: center;
        }
        
        .filter-group {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .filter-label {
            font-weight: 600;
            color: var(--text);
        }
        
        .filter-select {
            padding: 10px 15px;
            border: 2px solid var(--secondary-light);
            border-radius: 8px;
            background: var(--light);
            color: var(--text);
            font-family: 'Crimson Text', serif;
            min-width: 150px;
        }
        
        .search-box {
            position: relative;
            min-width: 300px;
        }
        
        .search-input {
            width: 100%;
            padding: 10px 15px 10px 45px;
            border: 2px solid var(--secondary-light);
            border-radius: 8px;
            background: var(--light);
            color: var(--text);
            font-family: 'Crimson Text', serif;
            font-size: 1rem;
        }
        
        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
        }
        
        .authors-grid {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px 60px;
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 30px;
        }
        
        .author-card-catalog {
            background: var(--light);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .author-card-catalog:hover {
            transform: translateY(-10px);
            box-shadow: var(--shadow-dark);
        }
        
        .author-image-catalog {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }
        
        .author-info-catalog {
            padding: 25px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }
        
        .author-name-catalog {
            font-size: 1.4rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 8px;
            line-height: 1.3;
        }
        
        .author-dates-catalog {
            color: var(--text-light);
            margin-bottom: 15px;
            font-size: 0.95rem;
        }
        
        .author-bio-catalog {
            color: var(--text);
            line-height: 1.6;
            margin-bottom: 20px;
            flex-grow: 1;
        }
        
        .author-tags-catalog {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 20px;
        }
        
        .author-tag-catalog {
            background: var(--secondary);
            color: var(--dark);
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .author-link-catalog {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            background: var(--primary);
            color: var(--light);
            text-decoration: none;
            border-radius: 6px;
            font-weight: 600;
            transition: all 0.3s ease;
            justify-content: center;
            margin-top: auto;
        }
        
        .author-link-catalog:hover {
            background: var(--accent);
            transform: translateY(-2px);
        }
        
        .catalog-stats {
            text-align: center;
            padding: 30px 0;
            background: var(--light-dark);
            margin-top: 40px;
        }
        
        .stats-grid {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 30px;
            padding: 0 20px;
        }
        
        .stat-item-catalog {
            text-align: center;
        }
        
        .stat-value-catalog {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--accent);
            margin-bottom: 10px;
            font-family: 'Playfair Display', serif;
        }
        
        .stat-label-catalog {
            color: var(--text-light);
            font-size: 1.1rem;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 40px 0;
            flex-wrap: wrap;
        }
        
        .page-link {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 45px;
            height: 45px;
            border: 2px solid var(--secondary-light);
            border-radius: 8px;
            color: var(--text);
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .page-link:hover, .page-link.active {
            background: var(--primary);
            color: var(--light);
            border-color: var(--primary);
        }
        
        @media (max-width: 768px) {
            .catalog-title {
                font-size: 2.2rem;
            }
            
            .catalog-filters {
                flex-direction: column;
                align-items: center;
            }
            
            .search-box {
                min-width: 100%;
            }
            
            .authors-grid {
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            }
        }
        
        @media (max-width: 576px) {
            .catalog-header {
                padding: 80px 0 40px;
            }
            
            .catalog-title {
                font-size: 1.8rem;
            }
            
            .authors-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: 1fr 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Панель навигации -->
    <header id="header">
        <div class="container">
            <nav>
                <div class="logo">
                    <i class="fas fa-book-open"></i>
                    <span>Классика Литературы</span>
                </div>
                <ul class="nav-links">
                    <li><a href="index.html" class="nav-link">Главная</a></li>
                    <li><a href="authors.html" class="nav-link active">Авторы</a></li>
                    <li><a href="index.html#works" class="nav-link">Произведения</a></li>
                    <li><a href="profile.html" class="nav-link">Профиль</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Хедер каталога -->
    <div class="catalog-header">
        <div class="container">
            <h1 class="catalog-title">Каталог авторов</h1>
            <p class="catalog-subtitle">Откройте для себя великих писателей мировой литературы и их бессмертные произведения</p>
        </div>
    </div>

    <!-- Фильтры и поиск -->
    <div class="catalog-filters">
        <div class="search-box">
            <i class="fas fa-search search-icon"></i>
            <input type="text" class="search-input" placeholder="Поиск авторов...">
        </div>
        
        <div class="filter-group">
            <span class="filter-label">Эпоха:</span>
            <select class="filter-select">
                <option value="all">Все эпохи</option>
                <option value="renaissance">Возрождение</option>
                <option value="enlightenment">Просвещение</option>
                <option value="romanticism">Романтизм</option>
                <option value="realism">Реализм</option>
                <option value="modernism">Модернизм</option>
            </select>
        </div>
        
        <div class="filter-group">
            <span class="filter-label">Страна:</span>
            <select class="filter-select">
                <option value="all">Все страны</option>
                <option value="russia">Россия</option>
                <option value="england">Англия</option>
                <option value="france">Франция</option>
                <option value="germany">Германия</option>
                <option value="usa">США</option>
            </select>
        </div>
        
        <div class="filter-group">
            <span class="filter-label">Сортировка:</span>
            <select class="filter-select">
                <option value="name">По имени</option>
                <option value="date">По дате</option>
                <option value="popular">По популярности</option>
            </select>
        </div>
    </div>

    <!-- Сетка авторов -->
    <div class="authors-grid" id="authors-container">
        <!-- Авторы будут загружены через JavaScript -->
    </div>

    <!-- Пагинация -->
    <div class="pagination">
        <a href="#" class="page-link active">1</a>
        <a href="#" class="page-link">2</a>
        <a href="#" class="page-link">3</a>
        <a href="#" class="page-link">4</a>
        <a href="#" class="page-link">
            <i class="fas fa-chevron-right"></i>
        </a>
    </div>

    <!-- Статистика -->
    <div class="catalog-stats">
        <div class="stats-grid">
            <div class="stat-item-catalog">
                <div class="stat-value-catalog">127</div>
                <div class="stat-label-catalog">Авторов в каталоге</div>
            </div>
            <div class="stat-item-catalog">
                <div class="stat-value-catalog">24</div>
                <div class="stat-label-catalog">Стран представлено</div>
            </div>
            <div class="stat-item-catalog">
                <div class="stat-value-catalog">543</div>
                <div class="stat-label-catalog">Произведений</div>
            </div>
            <div class="stat-item-catalog">
                <div class="stat-value-catalog">5+</div>
                <div class="stat-label-catalog">Литературных эпох</div>
            </div>
        </div>
    </div>

    <!-- Футер -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-column">
                    <div class="footer-logo">
                        <i class="fas fa-book-open"></i>
                        <span>Классика Литературы</span>
                    </div>
                    <p class="footer-description">Энциклопедия классической литературы для всех ценителей прекрасного. Мы стремимся сохранить и популяризировать мировое литературное наследие.</p>
                </div>
                <div class="footer-column">
                    <h3 class="footer-title">Разделы</h3>
                    <ul class="footer-links">
                        <li><a href="index.html"><i class="fas fa-chevron-right"></i> Главная</a></li>
                        <li><a href="authors.html"><i class="fas fa-chevron-right"></i> Авторы</a></li>
                        <li><a href="index.html#works"><i class="fas fa-chevron-right"></i> Произведения</a></li>
                        <li><a href="profile.html"><i class="fas fa-chevron-right"></i> Профиль</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3 class="footer-title">Сообщество</h3>
                    <ul class="footer-links">
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Форум</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Блог</a></li>
                        <li><a href="create-bio.html"><i class="fas fa-chevron-right"></i> Добавить автора</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Помощь проекту</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h3 class="footer-title">Контакты</h3>
                    <ul class="footer-links">
                        <li><a href="#"><i class="fas fa-chevron-right"></i> О нас</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Связаться с нами</a></li>
                        <li><a href="#"><i class="fas fa-chevron-right"></i> Политика конфиденциальности</a></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p class="copyright">&copy; 2023 Классика Литературы. Все права защищены.</p>
            </div>
        </div>
    </footer>

    <script>
        // Данные авторов
        const authors = [
            {
                id: 1,
                name: "Лев Толстой",
                dates: "1828 - 1910",
                bio: "Русский писатель, мыслитель, философ и публицист. Автор романов 'Война и мир', 'Анна Каренина'.",
                image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
                tags: ["Русская литература", "Реализм", "XIX век"],
                country: "russia",
                era: "realism"
            },
            {
                id: 2,
                name: "Фёдор Достоевский",
                dates: "1821 - 1881",
                bio: "Русский писатель, мыслитель, философ и публицист. Автор романов 'Преступление и наказание', 'Братья Карамазовы'.",
                image: "https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
                tags: ["Русская литература", "Психологизм", "XIX век"],
                country: "russia",
                era: "realism"
            },
            {
                id: 3,
                name: "Александр Пушкин",
                dates: "1799 - 1837",
                bio: "Русский поэт, драматург и прозаик, заложивший основы русского реалистического направления.",
                image: "https://images.unsplash.com/photo-1516979187457-637abb4f9353?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
                tags: ["Русская литература", "Золотой век", "Поэзия"],
                country: "russia",
                era: "romanticism"
            },
            {
                id: 4,
                name: "Уильям Шекспир",
                dates: "1564 - 1616",
                bio: "Английский поэт и драматург, считающийся величайшим англоязычным писателем.",
                image: "https://images.unsplash.com/photo-1576086213369-97a306d36557?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
                tags: ["Английская литература", "Ренессанс", "Драматургия"],
                country: "england",
                era: "renaissance"
            },
            {
                id: 5,
                name: "Антон Чехов",
                dates: "1860 - 1904",
                bio: "Русский писатель, прозаик, драматург. Классик мировой литературы.",
                image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
                tags: ["Русская литература", "Реализм", "Драматургия"],
                country: "russia",
                era: "realism"
            },
            {
                id: 6,
                name: "Николай Гоголь",
                dates: "1809 - 1852",
                bio: "Русский прозаик, драматург, поэт, критик, публицист, признанный одним из классиков русской литературы.",
                image: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
                tags: ["Русская литература", "Реализм", "Сатира"],
                country: "russia",
                era: "realism"
            },
            {
                id: 7,
                name: "Иван Тургенев",
                dates: "1818 - 1883",
                bio: "Русский писатель-реалист, поэт, публицист, драматург, переводчик.",
                image: "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
                tags: ["Русская литература", "Реализм", "XIX век"],
                country: "russia",
                era: "realism"
            },
            {
                id: 8,
                name: "Михаил Лермонтов",
                dates: "1814 - 1841",
                bio: "Русский поэт, прозаик, драматург, художник, офицер.",
                image: "https://images.unsplash.com/photo-1512820790803-83ca734da794?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80",
                tags: ["Русская литература", "Романтизм", "Поэзия"],
                country: "russia",
                era: "romanticism"
            }
        ];

        // Функция для отображения авторов
        function renderAuthors(authorsList) {
            const container = document.getElementById('authors-container');
            container.innerHTML = '';
            
            authorsList.forEach(author => {
                const authorCard = document.createElement('div');
                authorCard.className = 'author-card-catalog';
                authorCard.innerHTML = `
                    <img src="${author.image}" alt="${author.name}" class="author-image-catalog">
                    <div class="author-info-catalog">
                        <h3 class="author-name-catalog">${author.name}</h3>
                        <div class="author-dates-catalog">${author.dates}</div>
                        <p class="author-bio-catalog">${author.bio}</p>
                        <div class="author-tags-catalog">
                            ${author.tags.map(tag => `<span class="author-tag-catalog">${tag}</span>`).join('')}
                        </div>
                        <a href="author.html?id=${author.id}" class="author-link-catalog">
                            <i class="fas fa-user"></i> Подробнее
                        </a>
                    </div>
                `;
                container.appendChild(authorCard);
            });
        }

        // Функция для фильтрации авторов
        function filterAuthors() {
            const searchTerm = document.querySelector('.search-input').value.toLowerCase();
            const eraFilter = document.querySelectorAll('.filter-select')[0].value;
            const countryFilter = document.querySelectorAll('.filter-select')[1].value;
            
            const filteredAuthors = authors.filter(author => {
                const matchesSearch = author.name.toLowerCase().includes(searchTerm) || 
                                     author.bio.toLowerCase().includes(searchTerm);
                const matchesEra = eraFilter === 'all' || author.era === eraFilter;
                const matchesCountry = countryFilter === 'all' || author.country === countryFilter;
                
                return matchesSearch && matchesEra && matchesCountry;
            });
            
            renderAuthors(filteredAuthors);
        }

        // Инициализация страницы
        document.addEventListener('DOMContentLoaded', function() {
            // Первоначальная отрисовка авторов
            renderAuthors(authors);
            
            // Добавление обработчиков событий для фильтров
            document.querySelector('.search-input').addEventListener('input', filterAuthors);
            document.querySelectorAll('.filter-select').forEach(select => {
                select.addEventListener('change', filterAuthors);
            });
            
            // Обработчик для кнопок пагинации
            document.querySelectorAll('.page-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    // Удаляем активный класс у всех ссылок
                    document.querySelectorAll('.page-link').forEach(l => {
                        l.classList.remove('active');
                    });
                    
                    // Добавляем активный класс текущей ссылке
                    this.classList.add('active');
                    
                    // В реальном приложении здесь была бы загрузка данных для выбранной страницы
                    // Для демонстрации просто показываем уведомление
                    if (this.textContent && !isNaN(this.textContent)) {
                        showNotification(`Загружена страница ${this.textContent}`, 'info');
                    }
                });
            });
        });

        // Функция для показа уведомлений
        function showNotification(message, type = 'info') {
            // Создаем элемент уведомления
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.innerHTML = `
                <div class="notification-content">
                    <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
                    <span>${message}</span>
                </div>
            `;
            
            // Стили для уведомления
            notification.style.cssText = `
                position: fixed;
                top: 100px;
                right: 20px;
                background: var(--light);
                color: var(--text);
                padding: 15px 25px;
                border-radius: 8px;
                box-shadow: var(--shadow-dark);
                display: flex;
                align-items: center;
                gap: 10px;
                z-index: 10000;
                max-width: 400px;
                border-left: 4px solid ${type === 'success' ? 'var(--accent)' : 'var(--primary)'};
                transform: translateX(400px);
                transition: transform 0.3s ease;
            `;
            
            document.body.appendChild(notification);
            
            // Анимация появления
            setTimeout(() => {
                notification.style.transform = 'translateX(0)';
            }, 100);
            
            // Автоматическое закрытие
            setTimeout(() => {
                notification.style.transform = 'translateX(400px)';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.remove();
                    }
                }, 300);
            }, 3000);
        }
    </script>
</body>
</html>