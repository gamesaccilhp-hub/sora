<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets\css\style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;0,700;1,400&family=Playfair+Display:wght@400;500;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Баннер -->
    <section class="banner">
        <div class="banner-background"></div>
        <div class="container">
            <div class="banner-content">
                <h1 class="banner-title">Добро пожаловать
                    <br> в мир классической литературы</h1>
                <p class="banner-text">Откройте для себя величайшие произведения мировой литературы, их авторов и исторический контекст создания шедевров</p>
                <div class="banner-buttons">
                    <a href="#authors" class="btn btn-primary">Начать изучение <i class="fas fa-arrow-right"></i></a>
                    <a href="#" class="btn btn-secondary">О проекте <i class="fas fa-info-circle"></i></a>
                </div>
            </div>
        </div>
        <div class="scroll-indicator">
            <span>Листайте вниз</span>
            <div class="mouse">
                <div class="wheel"></div>
            </div>
        </div>
    </section>

    <!-- Возможности сайта -->
    <section class="features-section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">Возможности нашей вики</h2>
                <p class="section-subtitle">Исследуйте мир классической литературы с нашими инструментами</p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-pen-fancy"></i>
                    </div>
                    <h3 class="feature-title">Создание страниц</h3>
                    <p class="feature-description">Каждый зарегистрированный пользователь может создавать и редактировать страницы авторов и произведений, делиться своими исследованиями и анализами.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-lock-open"></i>
                    </div>
                    <h3 class="feature-title">Свободный доступ</h3>
                    <p class="feature-description">Весь контент доступен бесплатно без ограничений. Мы верим в свободное распространение знаний и культурного наследия.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">
                        <i class="fas fa-book"></i>
                    </div>
                    <h3 class="feature-title">Обширная библиотека</h3>
                    <p class="feature-description">Тысячи произведений с подробным анализом, историческим контекстом и критическими статьями от ведущих литературоведов.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Знаменитые авторы -->
    <section class="authors-section" id="authors">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title">Великие авторы</h2>
                <p class="section-subtitle">Познакомьтесь с гениями мировой литературы</p>
            </div>
            <div class="authors-grid">
                <div class="author-card">
                    <div class="author-image">
                        <img src="assets\images\Lev.jpg">
                        <div class="author-overlay">
                            <div class="author-quote">"Все счастливые семьи похожи друг на друга, каждая несчастливая семья несчастлива по-своему."</div>
                        </div>
                    </div>
                    <div class="author-info">
                        <h3 class="author-name">Лев Толстой</h3>
                        <p class="author-dates">1828 - 1910</p>
                        <p class="author-bio">Русский писатель, мыслитель, философ и публицист. Автор романов "Война и мир", "Анна Каренина".</p>
                        <div class="author-tags">
                            <span class="tag">Русская литература</span>
                            <span class="tag">Реализм</span>
                        </div>
                        <button class="btn btn-outline author-btn">Подробнее <i class="fas fa-chevron-right"></i></button>
                    </div>
                </div>
                <div class="author-card">
                    <div class="author-image">
                        <img src="assets\images\fyodor.jpg">
                        <div class="author-overlay">
                            <div class="author-quote">"Красота спасет мир."</div>
                        </div>
                    </div>
                    <div class="author-info">
                        <h3 class="author-name">Фёдор Достоевский</h3>
                        <p class="author-dates">1821 - 1881</p>
                        <p class="author-bio">Русский писатель, мыслитель, философ и публицист. Автор романов "Преступление и наказание", "Братья Карамазовы".</p>
                        <div class="author-tags">
                            <span class="tag">Русская литература</span>
                            <span class="tag">Психологизм</span>
                        </div>
                        <button class="btn btn-outline author-btn">Подробнее <i class="fas fa-chevron-right"></i></button>
                    </div>
                </div>
                <div class="author-card">
                    <div class="author-image">
                        <img src="assets\images\Alex.jpg">
                        <div class="author-overlay">
                            <div class="author-quote">"Любви все возрасты покорны."</div>
                        </div>
                    </div>
                    <div class="author-info">
                        <h3 class="author-name">Александр Пушкин</h3>
                        <p class="author-dates">1799 - 1837</p>
                        <p class="author-bio">Русский поэт, драматург и прозаик, заложивший основы русского реалистического направления.</p>
                        <div class="author-tags">
                            <span class="tag">Русская литература</span>
                            <span class="tag">Золотой век</span>
                        </div>
                        <button class="btn btn-outline author-btn">Подробнее <i class="fas fa-chevron-right"></i></button>
                    </div>
                </div>
                <div class="author-card">
                    <div class="author-image">
                        <img src="assets\images\Liam.jpg">
                        <div class="author-overlay">
                            <div class="author-quote">"Быть или не быть — вот в чем вопрос."</div>
                        </div>
                    </div>
                    <div class="author-info">
                        <h3 class="author-name">Уильям Шекспир</h3>
                        <p class="author-dates">1564 - 1616</p>
                        <p class="author-bio">Английский поэт и драматург, считающийся величайшим англоязычным писателем и одним из лучших драматургов мира.</p>
                        <div class="author-tags">
                            <span class="tag">Английская литература</span>
                            <span class="tag">Ренессанс</span>
                        </div>
                        <button class="btn btn-outline author-btn">Подробнее <i class="fas fa-chevron-right"></i></button>
                    </div>
                </div>

                <?php
                $sql = "SELECT * FROM authors";
                $authors = $connect -> query($sql);
                ?>
                <?php foreach($authors as $author):?>
                <div class="author-card">
                    <div class="author-image">
                        <img src="assets\images\Ivan.jpg">
                        <div class="author-overlay">
                            <div class="author-quote"><?=$author['quote']?></div>
                        </div>
                    </div>
                    <div class="author-info">
                        <h3 class="author-name"><?=$author['name']?></h3>
                        <p class="author-dates"><?=$author['date']?></p>
                        <p class="author-bio"><?=$author['description']?></p>
                        <div class="author-tags">
                            <span class="tag"><?=$author['genre']?></span>
                        </div>
                        <a href="/author?id=<?=$author['id']?>"><button class="btn btn-outline author-btn">Подробнее <i class="fas fa-chevron-right"></i></button></a>
                        
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    
    <!-- Цитата дня -->
    <section class="quote-section">
        <div class="container">
            <div class="quote-card">
                <div class="quote-icon">
                    <i class="fas fa-quote-left"></i>
                </div>
                <div class="quote-content">
                    <p class="quote-text" id="quote-text">"Человек создан для счастья, как птица для полета."</p>
                    <p class="quote-author" id="quote-author">— Владимир Короленко</p>
                </div>
                <div class="quote-actions">
                    <button id="new-quote-btn" class="btn btn-primary">
                        <i class="fas fa-sync-alt"></i> Новая цитата
                    </button>
                </div>
            </div>
        </div>
    </section>

    <script src="assets/js/script.js"></script>
</body>
</html>