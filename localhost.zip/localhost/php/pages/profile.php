<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Профиль - Классика Литературы</title>
    <link rel="stylesheet" href="asset\css\style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;0,700;1,400&family=Playfair+Display:wght@400;500;700;800&display=swap" rel="stylesheet">
</head>
<body>

    <!-- Секция профиля -->
    <section class="profile-section">
        <div class="container profile-container">
            <div class="profile-header">
                <h1 class="profile-title">Личный кабинет</h1>
                <p class="profile-subtitle">Управляйте вашим профилем, отслеживайте прогресс чтения и настройте параметры аккаунта</p>
            </div>

            <div class="profile-content">
                <!-- Боковая панель -->
                <div class="profile-sidebar">
                    <div class="profile-avatar">
                        <img src="https://i.pinimg.com/736x/d0/08/ff/d008ff63e4c08d333a86694c7cc81505.jpg" alt="Аватар" class="avatar-image">
                        <div class="avatar-upload">
                            <label for="avatar-upload" class="avatar-upload-label">
                                <i class="fas fa-camera"></i> Сменить фото
                            </label>
                            <input type="file" id="avatar-upload" accept="image/*">
                        </div>
                    </div>

                    <div class="profile-info">
                        <h2 class="profile-name"><?=$USER['name']?></h2>
                        <p class="profile-email"><?=$USER['email']?></p>
                    </div>

                    <ul class="profile-nav">
                        <li class="profile-nav-item">
                            <a href="#" class="profile-nav-link active" data-tab="overview">
                                <i class="fas fa-chart-line"></i>
                                <span>Обзор</span>
                            </a>
                        </li>
                        <li class="profile-nav-item">
                            <a href="#" class="profile-nav-link" data-tab="edit">
                                <i class="fas fa-user-edit"></i>
                                <span>Редактировать профиль</span>
                            </a>
                        </li>
                        <li class="profile-nav-item">
                            <a href="#" class="profile-nav-link" data-tab="favorites">
                                <i class="fas fa-heart"></i>
                                <span>Избранное</span>
                            </a>
                        </li>
                        <li class="profile-nav-item">
                            <a href="/add_author" class="profile-nav-link" data-tab="edit">
                                <i class="fas fa-user-edit"></i>
                                <span>Добавить запись</span>
                            </a>
                        </li>
                        <li class="profile-nav-item">
                            <a href="/exit" class="profile-nav-link" data-tab="edit">
                                <i class="fas fa-user-edit"></i>
                                <span>Выйти</span>
                            </a>
                        </li>
                    </ul>
                </div>

                <!-- Основная область -->
                <div class="profile-main">
                    <div class="profile-tabs">
                        <button class="profile-tab active" data-tab="overview">Обзор</button>
                        <button class="profile-tab" data-tab="favorites">Избранное</button>
                    </div>

                    <!-- Вкладка Обзор -->
                    <div id="overview-tab" class="tab-content active">
                        <div class="reading-stats">
                            <div class="reading-stat">
                                <i class="fas fa-book-open"></i>
                                <div class="reading-stat-value">0</div>
                                <div class="reading-stat-label">Создайно записей</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="assets\js\script.js"></script>
</body>
</html>