<?php
    // если есть get запрос id
    if(isset($_GET['id'])){
        // опреление id товрара
        $get_id = $_GET['id'];
        // sql запрос на чтение одного товара
        $sql = "SELECT * FROM authors WHERE id = $get_id";
        // создание масиива данных одного товара
        $author = $connect->query($sql)->fetch();
    }

    // если запущена форма edit
    if(isset($_POST['edit'])){
        // подготовка перменных
        $name = $_POST['name'];
        $date = $_POST['date'];
        $description = $_POST['description'];
        $genre = $_POST['genre'];

        // подготовка sql запроса на изменение в БД
        $sql = "UPDATE authors SET 
            name = '$name',
            date = '$date',
            description = '$description',
            genre = '$genre'
        WHERE id = $get_id";
        // запуск sql запроса
        $connect->query($sql);
        // перенаправление пользователя на страницу товара с id
        echo'<script>document.location.href="/author?id='.$get_id.'"</script>';

    }
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактировать биографию автора - Классика Литературы</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;0,700;1,400&family=Playfair+Display:wght@400;500;700;800&display=swap" rel="stylesheet">
</head>
<body>

    <!-- Секция создания записи -->
    <section class="create-section">
        <div class="container create-container">
            <div class="create-header">
                <h1 class="create-title"><?=$author['name']?></h1>
                <p class="create-subtitle">Редактируйте биографию литературного деятеля</p>
            </div>

            <div class="create-card">
                <form action="" class="create-form" method="post" name="edit">
                    <!-- Основная информация -->
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-info-circle"></i>
                            Основная информация
                        </h2>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="author-name" class="form-label required">Имя автора</label>
                                <input type="text" id="author-name" name="name" class="form-control" value="<?=$author['name']?>" required>
                                <div class="form-error"></div>
                            </div>
                            
                            <div class="form-group">
                                <label for="author-birthdate" class="form-label">Дата рождения</label>
                                <input type="text" id="author-birthdate" name="date" class="form-control" value="<?=$author['date']?>">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="author-genres" class="form-label">Основные жанры</label>
                            <input type="text" id="author-genres" class="form-control" name="genre" value="<?=$author['genre']?>">
                            <div class="form-description">Перечислите жанры через запятую</div>
                        </div>
                        <div class="form-group">
                            <label for="author-genres" class="form-label">Краткое описание</label>
                            <input type="text" id="author-description" class="form-control" name="description" value="<?=$author['description']?>">
                        </div>
                    </div>

                    <!-- Действия формы -->
                    <div class="form-actions">
                        <a type="button" href="/tovar" class="btn btn-outline btn-large">
                            <i class="fas fa-arrow-left"></i> Назад
                        </a>
                        <input type="submit" name="edit" class="btn btn-primary btn-large" value="Редактировать">
                    </div>
                </form>
            </div>
        </div>
    </section>
</body>
</html>