<?php
    // если запущена форма add
    if(isset($_POST['add'])){
        // подготовка перменных
        $name = $_POST['name'];
        $date = $_POST['date'];
        $description = $_POST['description'];
        $genre = $_POST['genre'];
        $quote = $_POST['quote'];


        // подготовка sql запроса на запись в БД
        $sql = "INSERT INTO authors (name,date,description,genre,quote) 
            VALUES ('$name','$date','$description','$genre','$quote')";
        // запуск sql запроса
        $connect -> query($sql);
        // перенаправление пользователя на страницу с товарами
        echo'<script>document.location.href="/"</script>';
        
    }
?>


<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Добавить биографию автора - Классика Литературы</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;0,700;1,400&family=Playfair+Display:wght@400;500;700;800&display=swap" rel="stylesheet">
</head>
<body>

    <!-- Секция создания записи -->
    <section class="create-section">
        <div class="container create-container">
            <div class="create-header">
                <h1 class="create-title">Добавить биографию автора</h1>
                <p class="create-subtitle">Создайте подробную биографию литературного деятеля</p>
            </div>

            <div class="create-card">
                <form class="create-form" method="post" name="add">
                    <!-- Основная информация -->
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-info-circle"></i>
                            Основная информация
                        </h2>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="author-name" class="form-label required">Имя автора</label>
                                <input type="text" id="author-name" name="name" class="form-control" placeholder="Лев Николаевич Толстой" required>
                                <div class="form-error"></div>
                            </div>
                            
                            <div class="form-group">
                                <label for="author-birthdate" class="form-label">Дата рождения</label>
                                <input type="text" id="author-birthdate" name="date" class="form-control" placeholder="0000-0000">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="author-genres" class="form-label">Основные жанры</label>
                            <input type="text" id="author-genres" class="form-control" name="genre" placeholder="Роман">
                        </div>

                        <div class="form-group">
                            <label for="author-genres" class="form-label">Краткое описание</label>
                            <input type="text" id="author-description" class="form-control" name="description" placeholder="Кратко расскажите об авторе">
                        </div>

                        <div class="form-group">
                            <label for="author-genres" class="form-label">Цитата</label>
                            <input type="text" id="author-quote" class="form-control" name="quote" placeholder="Вставьте любую цитату автора">
                        </div>
                    </div>

                    <!-- Портрет автора -->
                    <div class="form-section">
                        <h2 class="section-title">
                            <i class="fas fa-portrait"></i>
                            Портрет автора
                        </h2>
                        
                        <div class="form-group">
                            <div id="image-upload" class="image-upload">
                                <div class="upload-icon">
                                    <i class="fas fa-cloud-upload-alt"></i>
                                </div>
                                <div class="upload-text">Перетащите изображение или нажмите для загрузки</div>
                            </div>
                            <input type="file" id="author-image" name="img" accept="image/*" style="display: none;">
                            
                            <div id="upload-preview" class="upload-preview">
                                <img id="preview-image" src="" alt="Предпросмотр" class="preview-image">
                                <div class="preview-actions">
                                    <button type="button" class="btn btn-outline" id="remove-image">
                                        <i class="fas fa-times"></i> Удалить
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Действия формы -->
                    <div class="form-actions">
                        <a type="button" href="/profile" class="btn btn-outline btn-large">
                            <i class="fas fa-arrow-left"></i> Назад
                        </a>
                        <input type="submit" name="add" class="btn btn-primary btn-large" value="Опубликовать">
                    </div>
                </form>
            </div>
        </div>
    </section>

    <script>

        // Функции для страницы создания биографии автора
        function initCreatePage() {
            // Инициализация редактора контента
            initContentEditor();
            
            // Инициализация загрузки изображений
            initImageUpload();
        }
        
        // Инициализация редактора контента
        function initContentEditor() {
            const editor = document.getElementById('content-editor');
            const toolbar = document.querySelector('.editor-toolbar');
            
            if (!editor || !toolbar) return;
            
            // Обработчики для кнопок редактора
            toolbar.addEventListener('click', function(e) {
                if (e.target.classList.contains('editor-btn') || e.target.parentElement.classList.contains('editor-btn')) {
                    const button = e.target.classList.contains('editor-btn') ? e.target : e.target.parentElement;
                    const command = button.getAttribute('data-command');
                    const value = button.getAttribute('data-value');
                    
                    execEditorCommand(command, value, button);
                }
            });
            
            // Автосохранение содержимого
            editor.addEventListener('input', debounce(function() {
                autoSaveContent();
            }, 1000));
            
            // Обработка вставки текста с форматированием
            editor.addEventListener('paste', function(e) {
                e.preventDefault();
                const text = (e.clipboardData || window.clipboardData).getData('text/plain');
                document.execCommand('insertText', false, text);
            });
        }
        
        // Выполнение команд редактора
        function execEditorCommand(command, value, button) {
            if (command === 'formatBlock') {
                document.execCommand('formatBlock', false, value);
            } else if (command === 'createLink') {
                const url = prompt('Введите URL:');
                if (url) {
                    document.execCommand('createLink', false, url);
                }
            } else {
                document.execCommand(command, false, value);
            }
            
            // Обновление состояния кнопок
            updateEditorButtons();
            editor.focus();
        }
        
        // Обновление состояния кнопок редактора
        function updateEditorButtons() {
            const buttons = document.querySelectorAll('.editor-btn[data-command]');
            
            buttons.forEach(button => {
                const command = button.getAttribute('data-command');
                
                if (command === 'formatBlock') {
                    const value = button.getAttribute('data-value');
                    const isActive = document.queryCommandValue('formatBlock') === value;
                    button.classList.toggle('active', isActive);
                } else {
                    const isActive = document.queryCommandState(command);
                    button.classList.toggle('active', isActive);
                }
            });
        }

        // Инициализация загрузки изображений
        function initImageUpload() {
            const uploadArea = document.getElementById('image-upload');
            const fileInput = document.getElementById('author-image');
            const preview = document.getElementById('upload-preview');
            const previewImage = document.getElementById('preview-image');
            
            if (!uploadArea || !fileInput) return;
            
            // Обработчик клика по области загрузки
            uploadArea.addEventListener('click', function() {
                fileInput.click();
            });
            
            // Обработчик изменения файла
            fileInput.addEventListener('change', function(e) {
                handleImageUpload(e.target.files[0]);
            });
            
            // Обработчики drag & drop
            uploadArea.addEventListener('dragover', function(e) {
                e.preventDefault();
                uploadArea.classList.add('dragover');
            });
            
            uploadArea.addEventListener('dragleave', function() {
                uploadArea.classList.remove('dragover');
            });
            
            uploadArea.addEventListener('drop', function(e) {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    handleImageUpload(files[0]);
                }
            });
            
            // Обработчик удаления изображения
            const removeBtn = document.getElementById('remove-image');
            if (removeBtn) {
                removeBtn.addEventListener('click', function() {
                    preview.style.display = 'none';
                    fileInput.value = '';
                    uploadArea.style.display = 'block';
                });
            }
        }
        
        // Обработка загрузки изображения
        function handleImageUpload(file) {
            if (!file || !file.type.startsWith('image/')) {
                showNotification('Пожалуйста, выберите файл изображения', 'error');
                return;
            }
            
            if (file.size > 5 * 1024 * 1024) { // 5MB limit
                showNotification('Размер файла не должен превышать 5MB', 'error');
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(e) {
                const preview = document.getElementById('upload-preview');
                const previewImage = document.getElementById('preview-image');
                const uploadArea = document.getElementById('image-upload');
                
                previewImage.src = e.target.result;
                preview.style.display = 'block';
                uploadArea.style.display = 'none';
                
                showNotification('Изображение успешно загружено', 'success');
            };
            
            reader.readAsDataURL(file);
        }
        
        // Валидация и отправка формы
        function validateAndSubmitForm() {
            const form = document.getElementById('create-bio-form');
            const authorName = document.getElementById('author-name').value;
            
            if (!authorName.trim()) {
                showNotification('Введите имя автора', 'error');
                document.getElementById('author-name').focus();
                return false;
            }
            
            // Показать индикатор загрузки
            const submitBtn = form.querySelector('.btn-primary');
            const originalText = submitBtn.innerHTML;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Публикация...';
            submitBtn.disabled = true;
            
            return false;
        }
        
        // Вспомогательная функция для дебаунса
        function debounce(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
        
        // Загрузка данных при инициализации страницы
        function loadInitialData() {
            loadDraft();
            loadTimelineEvents();
            loadWorks();
        }
        
        // Инициализация страницы создания при загрузке DOM
        document.addEventListener('DOMContentLoaded', function() {
            // Если мы на странице создания биографии
            if (document.querySelector('.create-section')) {
                initCreatePage();
                loadInitialData();
            }
        });

    </script>
</body>
</html>