<!-- запрет на вход для авторизованных пользователей -->
<?php 
    if(isset($_SESSION['UID'])){
        echo'<script>document.location.href="/"</script>';
    } 
?>
<?php
// если есть запрос на авторизацию
if(isset($_POST['signin'])){
    // подготовка данных
    $password = $_POST['password'];
    $errors = [];

    // проверка пользователя с экранированием
    $params = [
        'email' => $_POST['email']
    ];
    $sql = "SELECT * FROM users WHERE email=:email";
    $prepare = $connect->prepare($sql);
    $prepare->execute($params);
    $signin_user = $prepare->fetch();

    // var_dump($signin_user);

    // проверка валидации
    if(empty($_POST['email'])){
        $errors['email'] = 'Введите почту';
    }elseif(empty($password)){
        $errors['password'] = 'Введите пароль';
    }elseif($signin_user == false){
        $errors['email'] = 'Пользователь не зарегистрирован';
    }elseif(!password_verify($password,$signin_user['password'])){
        $errors['password'] = 'Неверный пароль';
    }
    // если нет ошибок
    if(count($errors) == 0){
        $_SESSION['UID'] = $signin_user['id'];
        echo'<script>document.location.href="/profile"</script>';
    }
}
?>
<!-- Секция авторизации -->
<section class="auth-section">
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <div class="auth-logo">
                    <i class="fas fa-book-open"></i>
                    <span>LitWiki</span>
                </div>
                <h1 class="auth-title">Вход в аккаунт</h1>
                <p class="auth-subtitle">Войдите, чтобы получить доступ ко всем возможностям</p>
            </div>
            <form class="auth-form" id="login-form" method="post" name="signin">
                <div class="form-group">
                    <label for="email" class="form-label">Email адрес</label>
                    <input type="email" id="email" class="form-control" name="email" placeholder="your@email.com" required>
                    <i><?php if(isset($errors['email'])){echo $errors['email'];}?></i>
                    <div class="form-error"></div>
                </div>
                <div class="form-group">
                    <label for="password" class="form-label">Пароль</label>
                    <input type="password" id="password" class="form-control" name="password" placeholder="Введите ваш пароль" required>
                    <i><?php if(isset($errors['password'])){echo $errors['password'];}?></i>
                    <div class="form-error"></div>
                </div>
                <input type="submit" class="btn btn-primary auth-button" name="signin" value="Войти">
            </form>
            <div class="auth-footer">
                <p>Ещё нет аккаунта? <a href="/signup" class="auth-link">Зарегистрироваться</a></p>
            </div>
        </div>
    </div>
</section>