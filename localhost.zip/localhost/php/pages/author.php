<?php
    // если есть get запрос
    if(isset($_GET['id'])){
        // опреление id товрара
        $get_id = $_GET['id'];
        // sql запрос на чтение одного товара
        $sql = "SELECT * FROM authors WHERE id = $get_id";
        // создание масиива данных одного товара
        $author = $connect->query($sql)->fetch();
    }
?>

<?php 
    if(isset($_GET['del'])){
        $del_id = $_GET['del'];
        $sql = "DELETE authors WHERE id = '$del_id'";
        $connect->query($sql);
        echo'<script>document.location.href="/"</script>';
    }
?>

<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Иван Тургенев - Классика Литературы</title>
    <link rel="stylesheet" href="assets\css\style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;0,700;1,400&family=Playfair+Display:wght@400;500;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Хедер автора -->
    <div class="author-header">
        <div class="container author-header-content">
            <div class="author-portrait">
                <img src="assets\images\Ivan.jpg" class="author-images">
            </div>
            <div class="author-basic-info">
                <h1 class="author-names"><?=$author['name']?></h1>
                <div class="author-dates"><?=$author['date']?></div>
                <div class="author-quote"><?=$author['quote']?></div>
                <div class="author-tags">
                    <span class="author-tag"><?=$author['genre']?></span>
                </div>
                <?php if(isset($_SESSION['UID'])): ?>
                <div class="author-actions">
                    <a href="/edit?id=<?=$author['id']?>">
                        <button class="btn btn-primary">
                            <i class="fas fa-edit"></i> Редактировать
                        </button>
                    </a>
                    <a href="/delete&id=<?=$author['id']?>">   
                        <button class="btn btn-primary">
                            <i class="fas fa-edit"></i> Удалить
                        </button>
                    </a>
                </div>
                <?php endif ?>
            </div>
        </div>
    </div>

    <!-- Основной контент -->
    <section class="author-section">
        <div class="container author-container">
            <div class="author-content">
                <!-- Основная область -->
                <div class="author-main">
                    <!-- Биография -->
                    <section id="biography" class="author-section-content">
                        <h2 class="section-title">
                            <i class="fas fa-book"></i>
                            Биография
                        </h2>
                        <div class="biography-content">
                            <?=$author['description']?>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </section>
</body>
</html>
