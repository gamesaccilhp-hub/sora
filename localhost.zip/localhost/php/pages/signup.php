<?php
// если есть запрос signup
if(isset($_POST['signup'])){
    // подготовка данных из формы
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password2 = $_POST['password2'];
    // пустой массив ошибок
    $errors = [];

    // если не написано имя
    if(empty($_POST['name'])){
        // создание ошибки под поле имя
       $errors[0] = 'Введите имя';
    }

    // проверка пользователя по почте
    $sql = "SELECT * FROM users WHERE email = '$email'";
    $email_count = $connect->query($sql)->fetchColumn();

    // echo $email_count;

    // проверка почты
    if(empty($_POST['email'])){
        // если поле почта пустое
        $errors[1] = 'Введите почту';
    }elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        // если почта не по формату
        $errors[1] = 'Неверный формат почты';
    }elseif($email_count >= 1){
        // если пользователь уже зарегистрирован
        $errors[1] = 'Пользователь зарегистрирован';
    }

    // проверка пароля
    if(empty($password)){
        // если пусто
        $errors[2] = 'Введите пароль';
    }elseif(mb_strlen($password) < 6){
        // если менее 6 символов
        $errors[2] = 'Минимум 6 символа';
    }

    // проверка повтора пароля
    if($password != $password2){
        // если пароли не совподают
        $errors[3] = 'Пароли должны быть одинаковыми';
    }

    // если массив ошибок пустой
    if(count($errors) == 0){
        // хеширование пароля
        $pass = password_hash($password, PASSWORD_DEFAULT);
        // запись нового пользователя в БД
        $sql = "INSERT INTO users (name,email,password)
            VALUES ('$name','$email','$pass')";
        $connect->query($sql);
        // скрипт на главную страницу
        echo'<script>document.location.href="/signin"</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets\css\style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;0,700;1,400&family=Playfair+Display:wght@400;500;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Секция регистрации -->
    <section class="auth-section">
        <div class="auth-container">
            <div class="auth-card">
                <div class="auth-header">
                    <div class="auth-logo">
                        <i class="fas fa-book-open"></i>
                        <span>LitWiki</span>
                    </div>
                    <h1 class="auth-title">Создать аккаунт</h1>
                    <p class="auth-subtitle">Присоединяйтесь к нашему сообществу любителей литературы</p>
                </div>
                <form class="auth-form" id="register-form" method="post" name="signup">
                    <div class="form-group">
                        <label for="fullname" class="form-label">Полное имя</label>
                        <!-- если есть ранее введнные значения, вставить в инпут -->
                        <input type="text" name="name" value="<?php if(isset($name)){echo $name;}?>" id="fullname" class="form-control" placeholder="Александр" required>
                        <!-- если есть ошибка, вывести под инпутом -->
                        <i><?php if(isset($errors[0])){echo $errors[0];}?></i>
                        <div class="form-error">/div>
                    </div>
                    <div class="form-group">
                        <label for="reg-email" class="form-label">Email адрес</label>
                        <input type="text" name="email" value="<?php if(isset($email)){echo $email;}?>" id="reg-email" class="form-control" placeholder="your@email.com" required>
                        <i><?php if(isset($errors[1])){echo $errors[1];}?></i>
                        <div class="form-error"></div>
                    </div>
                    <div class="form-group">
                        <label for="reg-password" class="form-label">Пароль</label>
                        <input type="password" id="reg-password" class="form-control" name="password" placeholder="Не менее 6 символов" required>
                        <i><?php if(isset($errors[2])){echo $errors[2];}?></i>
                        <div class="form-error"></i></div>
                    </div>
                    <div class="form-group">
                        <label for="confirm-password" class="form-label">Подтверждение пароля</label>
                        <input type="password" id="confirm-password" class="form-control" name="password2" placeholder="Повторите пароль" required>
                        <i><?php if(isset($errors[3])){echo $errors[3];}?></i>
                        <div class="form-error"></div>
                    </div>
                    <input type="submit" class="btn btn-primary auth-button" name="signup" value="Зарегистрироваться">
                </form>
                <div class="auth-footer">
                    <p>Уже есть аккаунт? <a href="/signin" class="auth-link">Войти</a></p>
                </div>
            </div>
        </div>
    </section>
</body>
</html>