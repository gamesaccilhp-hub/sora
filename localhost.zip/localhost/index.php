<?php session_start()?> <!-- запуск сессии -->
<!-- Подключение файла для БД -->
<?php include('php\include\bd.php')?>
<!-- Подключение контроля авторизации -->
<?php include('php\include\auth_control.php')?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets\css\style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital,wght@0,400;0,600;0,700;1,400&family=Playfair+Display:wght@400;500;700;800&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Подключение хеадер -->
    <?php include('php\include\header.php') ?>

    <?php
        // маршрутизация страницы
        if(isset($_GET['q'])){
            $page = $_GET['q'];
            if(isset($_SESSION['UID'])){
                // список страниц только для авторизованного пользователя
                if($page == 'profile'){include('php\pages\profile.php');}
                if($page == 'add_author'){include('php\pages\add_author.php');}
                if($page == 'edit'){include('php\pages\edit.php');}
            }else{
                // список страниц только дл НЕавторизованного пользователя
                if($page == 'signup'){include('php\pages\signup.php');}
                if($page == 'signin'){include('php\pages\signin.php');}
            }

            // список страниц для всех
            if($page == 'authors'){include('php\pages\authors.php');}
            if($page == 'author'){include('php\pages\author.php');}

            
            
        }else{

            include('php\pages\start.php');
        }
    ?>

    <?php include('php\include\footer.php') ?>

</body>
</html>